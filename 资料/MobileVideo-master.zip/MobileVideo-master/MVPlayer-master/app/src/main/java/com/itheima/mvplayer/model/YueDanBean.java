package com.itheima.mvplayer.model;

import java.util.List;

public class YueDanBean {


    /**
     * playLists : [{"id":4585748,"title":"『天籁之音 空灵音乐之旅  』","thumbnailPic":"http://img1.yytcdn.com/video/mv/161208/2744679/-M-f86a48e923261e52fcf4d76b5dbd1e0c_240x135.jpg","playListPic":"http://img1.yytcdn.com/uploads/ka7HCyHe21.jpeg?size=110x110&size=600x600","playListBigPic":"http://img1.yytcdn.com/uploads/ka7HCyHe21.jpeg?size=600x600&size=600x600","videoCount":38,"description":"部分北欧,是童话世界,是丹麦安徒生笔下的小美人鱼;北欧,是自然世界,是挪威壮阔的峡湾,绝色的山光水色;北欧,是创意世界,是瑞典堪称经典的设计师在帮我们打造一个简约的理想时代。北欧像一个世外桃源,淡淡的节奏,空灵的曲调,使听者仿佛置身于仙境之中\u2026\u2026倾诉一下吧!                                                                                              欧美|清透舒适的旋律~","category":"个人专辑","creator":{"uid":41123512,"nickName":"Zjy这景宁静而优美","smallAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","largeAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","vipLevel":0},"status":0,"totalViews":5871,"totalFavorites":72,"updateTime":"2016-12-09 19:05","createdTime":"2016-12-08 19:33","integral":530,"weekIntegral":530,"totalUser":2,"rank":0},{"id":4586150,"title":"VEVO 2016年全球最热25支mv年榜","thumbnailPic":"http://img0.yytcdn.com/video/mv/151023/2400450/-M-f1619375d07a82544d6cb33a56c8d2ed_240x135.jpg","playListPic":"http://img4.c.yinyuetai.com/video/playlist/161209/0/-M-1e7b99646ef76886cc5bf7f4fb0f04e3_110x110.jpg","playListBigPic":"http://img4.c.yinyuetai.com/video/playlist/161209/0/-M-1e7b99646ef76886cc5bf7f4fb0f04e3_600x600.jpg","videoCount":25,"description":"VEVO发布2016年全球最热25支mv年榜!Justin Bieber冠单Sorry拿下双料冠军!这支mv也是VEVO史上观看人次最高的mv!还拿下了Billboard单曲年终榜亚军!Adele和五美Fifth Harmony分获亚季军!Calvin Harris、Rihanna、Drake、Bruno Mars、The Chainsmokers、Halsey挤进全球年榜Top 10!","category":"","creator":{"uid":2737879,"nickName":"Lucifer_Morningstar_","smallAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_50x50.jpg","largeAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_100x100.jpg","vipLevel":5,"vipImg":"http://img2.yytcdn.com/user/userAuth/140217/0/BA6F01443E0DBF9C47FD774B4BF21621_0x0.png"},"status":0,"totalViews":8084,"totalFavorites":139,"updateTime":"2016-12-09 19:45","createdTime":"2016-12-09 14:06","integral":100,"weekIntegral":100,"totalUser":1,"rank":0},{"id":4585302,"title":"2016 FNS歌谣祭 第一夜","thumbnailPic":"http://img4.yytcdn.com/video/mv/161207/0/258db817d2d7e693682a4eb685fdc851_240x135.jpg","playListPic":"http://img4.yytcdn.com/video/mv/161207/0/258db817d2d7e693682a4eb685fdc851_120x67.jpg","playListBigPic":"http://img4.yytcdn.com/video/mv/161207/0/258db817d2d7e693682a4eb685fdc851_240x135.jpg","videoCount":51,"description":"","category":"","creator":{"uid":777,"nickName":"小东瀛","smallAvatar":"http://img4.yytcdn.com/uploads/persons/a/777/64200139B48CA49272B8F2652731A890.jpg","largeAvatar":"http://img3.yytcdn.com/uploads/persons/a/777/7FB30139B48CA44CFC7260FB1324B3E4.jpg","vipLevel":5,"vipImg":"http://img2.yytcdn.com/user/userAuth/140217/0/BA6F01443E0DBF9C47FD774B4BF21621_0x0.png"},"status":0,"totalViews":19788,"totalFavorites":209,"updateTime":"2016-12-07 22:35","createdTime":"2016-12-07 21:38","integral":155,"weekIntegral":155,"totalUser":4,"rank":0},{"id":4585570,"title":"【盘点】超精彩电影预告你看了没!","thumbnailPic":"http://img3.c.yinyuetai.com/video/mv/161206/2744199/-M-8d0b44e67302321d96fe03403eadb8c5_240x135.jpg","playListPic":"http://img1.c.yinyuetai.com/video/playlist/161208/0/-M-e3ed00e72c24b3735b09f18038bc9f7b_110x110.jpg","playListBigPic":"http://img1.c.yinyuetai.com/video/playlist/161208/0/-M-e3ed00e72c24b3735b09f18038bc9f7b_600x600.jpg","videoCount":17,"description":"","category":"","creator":{"uid":1988428,"nickName":"音悦V榜","smallAvatar":"http://img4.yytcdn.com/user/avatar/130814/1988428/0D2E01407BDFEF857A653F4DBBB1A979_50x50.jpeg","largeAvatar":"http://img4.yytcdn.com/user/avatar/130814/1988428/0D2E01407BDFEF857A653F4DBBB1A979_100x100.jpeg","vipLevel":5,"vipImg":"http://img2.yytcdn.com/user/userAuth/140217/0/BA6F01443E0DBF9C47FD774B4BF21621_0x0.png"},"status":0,"totalViews":3333,"totalFavorites":18,"updateTime":"2016-12-08 14:05","createdTime":"2016-12-08 11:56","integral":0,"weekIntegral":0,"totalUser":0,"rank":0},{"id":4584110,"title":"聆听天籁,领略大自然予人之真谛","thumbnailPic":"http://img4.c.yinyuetai.com/video/mv/161020/2268530/-M-1c3201612334efed2c0edb114c22015f_240x135.jpg","playListPic":"http://img2.c.yinyuetai.com/video/playlist/161207/0/-M-57f0b6b7da0ae5b87f425544c97864fa_110x110.jpg","playListBigPic":"http://img2.c.yinyuetai.com/video/playlist/161207/0/-M-57f0b6b7da0ae5b87f425544c97864fa_600x600.jpg","videoCount":30,"description":"\"真正的音乐是在灵魂深处勾勒的东西,所有美好的音乐都来自最深的寂寞,岁月可以轻易的逝去,红颜可以匆忙的苍老,惟有那感人至深的乐符没能改变它最真至纯的本色 ...\"\n音乐变化流云飘逸,妩媚旋律宛如天籁之音,您仿佛身临其境,感受脱尘真实。知音结缘,领略大自然予人之真谛。","category":"","creator":{"uid":7639969,"nickName":"Mary","smallAvatar":"http://img2.yytcdn.com/user/avatar/160326/7639969-1459006135085/-M-0019785b486b847da44066991a13c21c_50x50.jpg","largeAvatar":"http://img2.yytcdn.com/user/avatar/160326/7639969-1459006135085/-M-0019785b486b847da44066991a13c21c_100x100.jpg","vipLevel":2,"vipImg":"http://img1.yytcdn.com/user/userAuth/140217/0/4BF301443E0D7E1D38BD65F1C7BEB485_0x0.png"},"status":0,"totalViews":8846,"totalFavorites":107,"updateTime":"2016-12-11 12:10","createdTime":"2016-12-05 13:45","integral":110,"weekIntegral":110,"totalUser":2,"rank":0},{"id":4585014,"title":"第59届格莱美四大通类提名","thumbnailPic":"http://img1.yytcdn.com/video/mv/160517/2572605/-M-eafc7177c446183f532ab69a91d0c6cf_240x135.jpg","playListPic":"http://img4.c.yinyuetai.com/video/playlist/161207/0/-M-27cd9212129be393e9811a2743174d4e_110x110.jpg","playListBigPic":"http://img4.c.yinyuetai.com/video/playlist/161207/0/-M-27cd9212129be393e9811a2743174d4e_600x600.jpg","videoCount":36,"description":"第59届格莱美四大通类提名揭晓!入围年度最佳专辑的包括Adele、Beyonce、Justin Bieber、Drake、Sturgill Simpson!入围年度最佳制作的包括Adele、Beyonce、Rihanna & Drake、Lukas Graham、21飞行员!入围年度最佳歌曲的包括Adele、Beyonce、Justin Bieber、Lukas Graham和Mike Posner!入围年度最佳新人的包烟鬼The Chainsmokers 、Kelsea Ballerini、Chance The Rapper 、Maren Morris和Anderson .Paak!","category":"","creator":{"uid":2737879,"nickName":"Lucifer_Morningstar_","smallAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_50x50.jpg","largeAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_100x100.jpg","vipLevel":5,"vipImg":"http://img2.yytcdn.com/user/userAuth/140217/0/BA6F01443E0DBF9C47FD774B4BF21621_0x0.png"},"status":0,"totalViews":5630,"totalFavorites":80,"updateTime":"2016-12-07 21:15","createdTime":"2016-12-07 07:17","integral":5,"weekIntegral":5,"totalUser":1,"rank":0},{"id":4584236,"title":"最好听的欧美说唱&Hip-Hop歌曲精选","thumbnailPic":"http://img3.yytcdn.com/video/mv/160129/0/-M-e1c5e8798220a27eae248db187e23c56_240x135.jpg?ts=1454061881","playListPic":"http://img1.c.yinyuetai.com/video/playlist/161205/0/-M-86932fe72a88e6ad1a9ea978ab1ab888_110x110.jpg?size=600x600","playListBigPic":"http://img1.c.yinyuetai.com/video/playlist/161205/0/-M-86932fe72a88e6ad1a9ea978ab1ab888_600x600.jpg?size=600x600","videoCount":36,"description":"","category":"","creator":{"uid":7639969,"nickName":"Mary","smallAvatar":"http://img2.yytcdn.com/user/avatar/160326/7639969-1459006135085/-M-0019785b486b847da44066991a13c21c_50x50.jpg","largeAvatar":"http://img2.yytcdn.com/user/avatar/160326/7639969-1459006135085/-M-0019785b486b847da44066991a13c21c_100x100.jpg","vipLevel":2,"vipImg":"http://img1.yytcdn.com/user/userAuth/140217/0/4BF301443E0D7E1D38BD65F1C7BEB485_0x0.png"},"status":0,"totalViews":8857,"totalFavorites":148,"updateTime":"2016-12-11 12:10","createdTime":"2016-12-05 19:21","integral":0,"weekIntegral":0,"totalUser":0,"rank":0},{"id":4584627,"title":"李健 传奇","thumbnailPic":"http://img0.c.yinyuetai.com/video/mv/150722/2334766/-M-fac8afb73b17465d3cd2f638f9dd58c0_240x135.jpg","playListPic":"http://img1.c.yinyuetai.com/video/playlist/161206/0/-M-0b3ef924d649ad1446880ff752ddcfe7_110x110.jpg","playListBigPic":"http://img1.c.yinyuetai.com/video/playlist/161206/0/-M-0b3ef924d649ad1446880ff752ddcfe7_600x600.jpg","videoCount":22,"description":"","category":"","creator":{"uid":19742647,"nickName":"fuerdi_26681","smallAvatar":"http://tp3.sinaimg.cn/3299206114/180/5660795735/0","largeAvatar":"http://tp3.sinaimg.cn/3299206114/180/5660795735/0","vipLevel":3,"vipImg":"http://img4.yytcdn.com/user/userAuth/140217/0/58A101443E0DADE42D3C66E640D268EC_0x0.png"},"status":0,"totalViews":6242,"totalFavorites":51,"updateTime":"2016-12-08 16:15","createdTime":"2016-12-06 13:32","integral":60,"weekIntegral":60,"totalUser":2,"rank":0},{"id":4583340,"title":"如此凄美的雪景、如此妩媚------每个冬天,每个雪景","thumbnailPic":"http://img0.yytcdn.com/video/mv/160811/2646367/-M-3077fd86b898eb296653ebbc42f3a6ca_240x135.jpg","playListPic":"http://img1.yytcdn.com/uploads/G2KDjHsNR3.jpeg?size=110x110&size=600x600","playListBigPic":"http://img1.yytcdn.com/uploads/G2KDjHsNR3.jpeg?size=600x600&size=600x600","videoCount":59,"description":"如此凄美的雪景、如此妩媚的月色\n\n弹指一挥间,流年不复返。风雪交错的夜里,月色显得有些苍茫,窗外的灯火也不似从前那般明亮。只有我依旧如此,欣赏着夜的凄美,品味着夜的芬芳。\n静逸风格的音乐,这类音乐让人联想到凉爽的夏夜,静寂的雪景,阴郁的森林,潮湿的古镇..... \n                                                                                                      佳期如梦,思念化雪。修一山清风,落一场香雪,赴一场约定,得一季宿缘。任雪花落在秀发,钻入怀里,落在眉间,这样的日子,徜徉在天地间,内心清澈,了无杂念,这一刻,混沌散开,污浊逸去,天地白茫茫,真干净!\n粒粒雪子,霏霏如萤,落叶为露,覆土成泥,入手心不见。这一场浩雪,这一程山水,来时随喜,去时随乐。只是。来的那一天,花等得凋落了,叶等得飘零了,水等得凝固了,万物都在静默着、等待着。","category":"个人专辑","creator":{"uid":41123512,"nickName":"Zjy这景宁静而优美","smallAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","largeAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","vipLevel":0},"status":0,"totalViews":8030,"totalFavorites":126,"updateTime":"2016-12-04 19:40","createdTime":"2016-12-04 13:26","integral":36,"weekIntegral":36,"totalUser":6,"rank":0},{"id":4584099,"title":"Capital s Jingle 2016","thumbnailPic":"http://img2.c.yinyuetai.com/video/mv/161205/2743307/-M-2ae2504b950ec0fbb852fe22aa4071b0_240x135.jpg","playListPic":"http://img1.c.yinyuetai.com/video/playlist/161205/0/-M-7d70e2f245be1968fbb5fabc70167fc5_110x110.jpg","playListBigPic":"http://img1.c.yinyuetai.com/video/playlist/161205/0/-M-7d70e2f245be1968fbb5fabc70167fc5_600x600.jpg","videoCount":64,"description":"Capital s Jingle 2016现场视频合辑放出!年年Years & Years、DNCE、小混混Little Mix、Nathan Sykes、Dua Lipa、绵羊Ellie Goulding、高富帅Calvin Harris、囧立Olly Murs、Clean Bandit 等多位欧美艺人纷纷现身!火爆热单现场悦单视频都在其中,绝对不要错过哦~","category":"","creator":{"uid":2737879,"nickName":"Lucifer_Morningstar_","smallAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_50x50.jpg","largeAvatar":"http://img1.yytcdn.com/user/avatar/161113/2737879-1479038562161/-M-95a8f7a2b06b67e16af470458142dcc7_100x100.jpg","vipLevel":5,"vipImg":"http://img2.yytcdn.com/user/userAuth/140217/0/BA6F01443E0DBF9C47FD774B4BF21621_0x0.png"},"status":0,"totalViews":5415,"totalFavorites":48,"updateTime":"2016-12-06 10:40","createdTime":"2016-12-05 13:07","integral":5,"weekIntegral":5,"totalUser":1,"rank":0}]
     * totalCount : 2222
     */

    private int totalCount;
    /**
     * id : 4585748
     * title : 『天籁之音 空灵音乐之旅  』
     * thumbnailPic : http://img1.yytcdn.com/video/mv/161208/2744679/-M-f86a48e923261e52fcf4d76b5dbd1e0c_240x135.jpg
     * playListPic : http://img1.yytcdn.com/uploads/ka7HCyHe21.jpeg?size=110x110&size=600x600
     * playListBigPic : http://img1.yytcdn.com/uploads/ka7HCyHe21.jpeg?size=600x600&size=600x600
     * videoCount : 38
     * description : 部分北欧,是童话世界,是丹麦安徒生笔下的小美人鱼;北欧,是自然世界,是挪威壮阔的峡湾,绝色的山光水色;北欧,是创意世界,是瑞典堪称经典的设计师在帮我们打造一个简约的理想时代。北欧像一个世外桃源,淡淡的节奏,空灵的曲调,使听者仿佛置身于仙境之中……倾诉一下吧!                                                                                              欧美|清透舒适的旋律~
     * category : 个人专辑
     * creator : {"uid":41123512,"nickName":"Zjy这景宁静而优美","smallAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","largeAvatar":"http://tp1.sinaimg.cn/5687879464/50/5735615872/0","vipLevel":0}
     * status : 0
     * totalViews : 5871
     * totalFavorites : 72
     * updateTime : 2016-12-09 19:05
     * createdTime : 2016-12-08 19:33
     * integral : 530
     * weekIntegral : 530
     * totalUser : 2
     * rank : 0
     */

    private List<PlayListsBean> playLists;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<PlayListsBean> getPlayLists() {
        return playLists;
    }

    public void setPlayLists(List<PlayListsBean> playLists) {
        this.playLists = playLists;
    }

    public static class PlayListsBean {
        private int id;
        private String title;
        private String thumbnailPic;
        private String playListPic;
        private String playListBigPic;
        private int videoCount;
        private String description;
        private String category;
        /**
         * uid : 41123512
         * nickName : Zjy这景宁静而优美
         * smallAvatar : http://tp1.sinaimg.cn/5687879464/50/5735615872/0
         * largeAvatar : http://tp1.sinaimg.cn/5687879464/50/5735615872/0
         * vipLevel : 0
         */

        private CreatorBean creator;
        private int status;
        private int totalViews;
        private int totalFavorites;
        private String updateTime;
        private String createdTime;
        private int integral;
        private int weekIntegral;
        private int totalUser;
        private int rank;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getThumbnailPic() {
            return thumbnailPic;
        }

        public void setThumbnailPic(String thumbnailPic) {
            this.thumbnailPic = thumbnailPic;
        }

        public String getPlayListPic() {
            return playListPic;
        }

        public void setPlayListPic(String playListPic) {
            this.playListPic = playListPic;
        }

        public String getPlayListBigPic() {
            return playListBigPic;
        }

        public void setPlayListBigPic(String playListBigPic) {
            this.playListBigPic = playListBigPic;
        }

        public int getVideoCount() {
            return videoCount;
        }

        public void setVideoCount(int videoCount) {
            this.videoCount = videoCount;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public CreatorBean getCreator() {
            return creator;
        }

        public void setCreator(CreatorBean creator) {
            this.creator = creator;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getTotalViews() {
            return totalViews;
        }

        public void setTotalViews(int totalViews) {
            this.totalViews = totalViews;
        }

        public int getTotalFavorites() {
            return totalFavorites;
        }

        public void setTotalFavorites(int totalFavorites) {
            this.totalFavorites = totalFavorites;
        }

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public String getCreatedTime() {
            return createdTime;
        }

        public void setCreatedTime(String createdTime) {
            this.createdTime = createdTime;
        }

        public int getIntegral() {
            return integral;
        }

        public void setIntegral(int integral) {
            this.integral = integral;
        }

        public int getWeekIntegral() {
            return weekIntegral;
        }

        public void setWeekIntegral(int weekIntegral) {
            this.weekIntegral = weekIntegral;
        }

        public int getTotalUser() {
            return totalUser;
        }

        public void setTotalUser(int totalUser) {
            this.totalUser = totalUser;
        }

        public int getRank() {
            return rank;
        }

        public void setRank(int rank) {
            this.rank = rank;
        }

        public static class CreatorBean {
            private int uid;
            private String nickName;
            private String smallAvatar;
            private String largeAvatar;
            private int vipLevel;

            public int getUid() {
                return uid;
            }

            public void setUid(int uid) {
                this.uid = uid;
            }

            public String getNickName() {
                return nickName;
            }

            public void setNickName(String nickName) {
                this.nickName = nickName;
            }

            public String getSmallAvatar() {
                return smallAvatar;
            }

            public void setSmallAvatar(String smallAvatar) {
                this.smallAvatar = smallAvatar;
            }

            public String getLargeAvatar() {
                return largeAvatar;
            }

            public void setLargeAvatar(String largeAvatar) {
                this.largeAvatar = largeAvatar;
            }

            public int getVipLevel() {
                return vipLevel;
            }

            public void setVipLevel(int vipLevel) {
                this.vipLevel = vipLevel;
            }
        }
    }
}
