package com.itheima.mvplayer.view;

public interface MVView {
    void onLoadAreaFailed();

    void onLoadAreaSuccess();
}
